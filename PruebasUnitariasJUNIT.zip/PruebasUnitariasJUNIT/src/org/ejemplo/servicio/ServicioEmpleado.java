package org.ejemplo.servicio;

public class ServicioEmpleado {
	public double salarioBono(double salario, double bono) {
		return salario + bono;
	}
	
	public double salarioPerstamo(double salario, double prestamo) {
		return salario-prestamo;
	}

}
